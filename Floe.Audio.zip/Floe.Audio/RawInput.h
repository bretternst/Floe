#pragma once
#include "Stdafx.h"
#include "InputButton.h"

namespace Floe
{
	namespace Audio
	{
		using System::Windows::Window;
		using System::Windows::Interop::WindowInteropHelper;
		using System::IntPtr;

		public ref class RawInputEventArgs : System::EventArgs
		{
		private:
			InputButton m_button;

		public:
			property InputButton Button
			{
				InputButton get()
				{
					return m_button;
				}
			}

		internal:
			RawInputEventArgs(InputButton button) : m_button(button) {}
		};

		public ref class RawInput
		{
		public:
			static void Initialize(Window ^window);
			static void HandleInput(IntPtr lParam);
		};
	}
}